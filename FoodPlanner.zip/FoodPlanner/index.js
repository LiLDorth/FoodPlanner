const express = require('express')
const path = require('path')
var bodyParser = require('body-parser');
var session = require('express-session');
var passport = require('passport');
var util = require('util');
var facebookStrategy = require('passport-facebook');
var cookieParser = require('cookie-parser');
var config = module.exports={
  "facebook_api_key"      :     "184541618839311",
  "facebook_api_secret"   :     "9c611c31164e720829df355e5ddccb4d",
  "callback_url"          :     "http://localhost:5000/auth/facebook/callback",
  "use_database"          :     "true",
  "host"                  :     "localhost",
  "username"              :     "root",
  "password"              :     "",
  "database"              :     "foodplan"
};

const request = require('request');

const { Pool } = require('pg');
const PORT = process.env.PORT || 5000;

const connectionString = process.env.DATABASE_URL || 'postgres://postgres:server@localhost:5432/foodplan';
const pool = new Pool({
	connectionString: connectionString
    //SSL: true;
});


express()
	.use(express.static(path.join(__dirname, 'public')))
	.use(bodyParser.json())
	.use(bodyParser.urlencoded({extended: true}))
	//.use(session({
		//username:'team12-session',
		//user_id: 'supersecretsecret',
		//saveUninitialized: true,
		//resave: false
	//}))
	.use('/', logRequest)
	.post('/login', login)
	.post('/logout', logout)
    .post('/addItem', additem)
    .get('/getdayplan/:date', getdayplan)
    .get('/getItem/:name', lookUp)
	.get('/getServerTime', verifyLogin, getServerTime)
	.listen(PORT, () => console.log(`Listening on ${PORT}`))


function login(req, res) {
	var user = req.body.username;
	var pass = req.body.password;

	query = 'SELECT user_id, username FROM public.user WHERE username = $1';
}

function logout(req, res) {
	if (req.session.user) {
		req.session.destroy();
		res.json({success:true});
	} else {
		res.json({success:false});
	}
}

function additem(req, res) {
    
    var date = req.body.Date;
    var meal = req.body.Time;
    
    query = 'INSERT INTO public.mealplan(user_id, day, ';
    
    switch (meal) {
        case 'breakfast':
            query += meal;
            break;
            case'lunch':
            query += meal;
            break;
            case'dinner':
            query += meal;
            break;
        default:
            return;
            
    }
    
    query += ") VALUES ('1', '" + date + "', '" + JSON.stringify(req.body) + "');";
    
    pool.query(query, function(err, res) {
		if (err) {
			throw err;
		} else {
			// We got a result from the db...
			console.log('Back from DB with: ' + res.rows);

			var result = {
				status: 'success',
				list: res.rows
			};

			console.log(result);}
		});
        res.send(req.body);
	}


function getdayplan(req, res) {
    var day = req.params.date;
    
    pool.query("SELECT breakfast, lunch, dinner FROM mealplan WHERE user_id = '1' AND day = '" + day + "'", function(err, response) {
		if (err) {
			throw err;
		} else {
			// We got a result from the db...
			console.log('Back from DB with: ' + response.rows);

			var result = {
				status: 'success',
				list: response.rows
			};

			console.log(result);
            res.json(response.rows);
        }        
		});
        
	}

function lookUp(req, res) {
    options = {  
    url: 'https://trackapi.nutritionix.com/v2/search/instant',
    method: 'GET',
    headers: {
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8',
        'User-Agent': 'Foodplanner',
        'x-app-id': '08968769',
        'x-app-key': '2ad9cb71f6fb40425332957ab31e8d21'
        
    }, 
    qs: {
    query: req.params.name
}
};
    request(options, function(err, response, body) {
        if (!err && response.statusCode == 200) {
            console.log('Successfull API Connect');
            items = JSON.parse(body);
            res.json(items);
        }
        else
            console.log(err);
    }
)}

function getServerTime(req, res) {
	res.json({success: true, time : new Date()});
}

function logRequest(req, res, next) {
	console.log('Received a request for: ' + req.url);
	next();
}

function verifyLogin(req, res, next){
	if (req.session.username)
		next();
	else{
		var result = {success: false, message:"You are unauthorized to be here, shoo!"};
		res.status(401).send(result);
	}
}

