var express = require('express');
var app = express();

app.set('port', 5000)
  .use(express.json())       // to support JSON-encoded bodies
  .use(express.urlencoded({extended:true})) // to support URL-encoded bodies
  .get('/game/:id', handleSingleGame)
  .get('/games', handleGameList)
  .post('/game', handleNewGame)
  .listen(app.get('port'), function() {
  	console.log('Listening on port: ' + app.get('port'));
  });

function handleNewGame(req, res) {
	console.log('Creating new game...');

	var title = req.body.title;

	console.log('The title is: ' + title);


	res.json({success:true});
}

function handleSingleGame(req, res) {
	var id = req.params.id;
	console.log('Getting single game with id: ' + id);

	var result = {id: id, title: 'Super Smash Bros'};

	res.json(result);
}

function handleGameList(req, res) {
	console.log('Getting game list');

	var resultList = [{id:1, title:'Oregon Trail'},
					  {id:2, title:'Night in the Woods'},
					  {id:3, title:'Mario Kart'}];

	res.json(resultList);
}

















const express = require('express')
const path = require('path')
const PORT = process.env.PORT || 5000

express()
  .use(express.static(path.join(__dirname, 'public')))
  .set('views', path.join(__dirname, 'views'))
  .set('view engine', 'ejs')
  .get('/math', handleMath)
  .get('/', (req, res) => res.render('pages/index'))
  .listen(PORT, () => console.log(`Listening on ${ PORT }`))


function handleMath(req, res) {
    console.log('Handle');
    var num1 = req.query.num1;
    var op = req.query.type;
    var num2 = req.query.num2;
    var results = num1 num2
    res.render('pages/results', {type: op, numOne: num1, numTwo: num2 });
}